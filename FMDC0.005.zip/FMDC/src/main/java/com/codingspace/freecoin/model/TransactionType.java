package com.codingspace.freecoin.model;

public enum TransactionType {
    /** Credit */
    C,
    /** Debit */
    D
}
